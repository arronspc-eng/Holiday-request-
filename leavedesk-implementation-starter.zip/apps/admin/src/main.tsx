import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import './style.css';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
const supabase = createClient(url || 'https://example.supabase.co', key || 'missing-key');
type Request = { id: string; employee_name: string; start_date: string; end_date: string; working_days: number; leave_type: string; employee_note: string | null; status: string };
function App() {
  const [session, setSession] = useState<any>(null);
  const [rows, setRows] = useState<Request[]>([]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  async function load() {
    const { data: s } = await supabase.auth.getSession();
    setSession(s.session);
    if (!s.session) return;
    const { data, error } = await supabase.rpc('manager_pending_requests');
    if (error) setMessage(error.message);
    else setRows((data ?? []) as Request[]);
  }
  useEffect(() => {
    void load();
    const { data } = supabase.auth.onAuthStateChange(() => void load());
    return () => data.subscription.unsubscribe();
  }, []);
  async function signIn() {
    setBusy(true);
    const provider = (import.meta.env.VITE_AUTH_PROVIDER || 'azure') as any;
    const { error } = await supabase.auth.signInWithOAuth({ provider, options: { redirectTo: window.location.origin, scopes: 'openid profile email' } });
    if (error) setMessage(error.message);
    setBusy(false);
  }
  async function decide(id: string, decision: 'approve' | 'decline') {
    setBusy(true); setMessage('');
    const { error } = await supabase.rpc('decide_leave_request', { p_request_id: id, p_decision: decision, p_manager_note: null });
    if (error) setMessage(error.message);
    else { setMessage(`Request ${decision === 'approve' ? 'approved' : 'declined'}.`); await load(); }
    setBusy(false);
  }
  if (!session) return <main className="login"><div className="brand">Leave<span>Desk</span></div><h1>HR & manager workspace</h1><p>Sign in with your company identity provider to review leave requests.</p><button onClick={signIn} disabled={busy}>{busy ? 'Opening sign-in…' : 'Sign in with company account'}</button>{message && <p className="message">{message}</p>}</main>;
  return <div className="app"><aside><div className="brand">Leave<span>Desk</span></div><p className="small">HR WORKSPACE</p><div className="nav active">✓ &nbsp; Approvals</div><div className="nav">▦ &nbsp; Team calendar <small>Planned</small></div><div className="nav">⚙ &nbsp; Leave policies <small>Planned</small></div><button className="signout" onClick={() => supabase.auth.signOut()}>Sign out</button></aside><main className="content"><header><div><p className="small">MANAGER WORKSPACE</p><h1>Leave approvals</h1><p>Review requests assigned to you.</p></div><div className="user">{session.user.email}</div></header>{message && <div className="message">{message}</div>}<section className="metric"><span>Requests awaiting review</span><strong>{rows.length}</strong></section><section className="tablecard"><h2>Pending requests</h2>{rows.length === 0 ? <div className="empty">No requests awaiting your decision.</div> : <div className="tablewrap"><table><thead><tr><th>Employee</th><th>Dates</th><th>Days</th><th>Leave type</th><th>Note</th><th>Decision</th></tr></thead><tbody>{rows.map(r => <tr key={r.id}><td>{r.employee_name}</td><td>{r.start_date} – {r.end_date}</td><td>{r.working_days}</td><td>{r.leave_type}</td><td>{r.employee_note || '—'}</td><td><div className="actions"><button className="approve" disabled={busy} onClick={() => void decide(r.id, 'approve')}>Approve</button><button className="decline" disabled={busy} onClick={() => void decide(r.id, 'decline')}>Decline</button></div></td></tr>)}</tbody></table></div>}</section><p className="footer">LeaveDesk starter · Company data is protected by server-side access policies.</p></main></div>;
}
createRoot(document.getElementById('root')!).render(<React.StrictMode><App /></React.StrictMode>);
