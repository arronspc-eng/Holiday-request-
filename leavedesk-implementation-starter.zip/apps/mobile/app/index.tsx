import { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Modal, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import * as WebBrowser from 'expo-web-browser';
import * as Linking from 'expo-linking';
import { supabase } from '../lib/supabase';

WebBrowser.maybeCompleteAuthSession();

type RequestRow = {
  id: string; start_date: string; end_date: string; working_days: number;
  leave_type: string; status: string; employee_note: string | null;
};
type Profile = { display_name: string; role: string; organisation_id: string; annual_entitlement_days: number | null };

export default function Home() {
  const [session, setSession] = useState<any>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [requests, setRequests] = useState<RequestRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [bookingOpen, setBookingOpen] = useState(false);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [note, setNote] = useState('');

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (data.session) void loadData();
      else setLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      if (nextSession) void loadData();
      else { setProfile(null); setRequests([]); setLoading(false); }
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  async function loadData() {
    setLoading(true);
    const { data: p, error: pError } = await supabase.rpc('my_leave_profile');
    if (pError) Alert.alert('Could not load profile', pError.message);
    else setProfile((p?.[0] ?? null) as Profile | null);
    const { data: r, error: rError } = await supabase.rpc('my_leave_requests');
    if (rError) Alert.alert('Could not load requests', rError.message);
    else setRequests((r ?? []) as RequestRow[]);
    setLoading(false);
  }

  async function signIn() {
    setBusy(true);
    try {
      const redirectTo = Linking.createURL('auth/callback');
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: (process.env.EXPO_PUBLIC_AUTH_PROVIDER as any) || 'azure',
        options: { redirectTo, skipBrowserRedirect: true, scopes: 'openid profile email' },
      });
      if (error) throw error;
      if (!data.url) throw new Error('The identity provider did not return a sign-in URL.');
      const result = await WebBrowser.openAuthSessionAsync(data.url, redirectTo);
      if (result.type === 'success' && result.url) {
        const parsed = Linking.parse(result.url);
        const params = parsed.queryParams ?? {};
        if (typeof params.access_token === 'string' && typeof params.refresh_token === 'string') {
          const { error: sessionError } = await supabase.auth.setSession({
            access_token: params.access_token, refresh_token: params.refresh_token,
          });
          if (sessionError) throw sessionError;
        } else {
          const hash = result.url.split('#')[1] ?? '';
          const hashParams = new URLSearchParams(hash);
          const access_token = hashParams.get('access_token');
          const refresh_token = hashParams.get('refresh_token');
          if (access_token && refresh_token) {
            const { error: sessionError } = await supabase.auth.setSession({ access_token, refresh_token });
            if (sessionError) throw sessionError;
          } else {
            Alert.alert('Sign-in completed', 'If you are not signed in, configure the identity provider redirect URL and native deep link for your provider.');
          }
        }
      }
    } catch (e: any) {
      Alert.alert('Sign-in error', e?.message ?? 'Please try again.');
    } finally { setBusy(false); }
  }

  async function requestLeave() {
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) return;
    // Starter prompt is deliberately simple; replace with a calendar/date-picker screen before pilot.
    Alert.alert('Booking screen required', 'The backend request RPC is ready. Add a date-picker form to collect start date, end date, leave type and note before enabling employee booking.');
  }

  async function signOut() { await supabase.auth.signOut(); }

  if (loading) return <SafeAreaView style={styles.center}><ActivityIndicator size="large" color="#147D64" /><Text style={styles.muted}>Loading LeaveDesk…</Text></SafeAreaView>;

  if (!session) return <SafeAreaView style={styles.center}>
    <View style={styles.brandMark}><Text style={styles.markText}>LD</Text></View>
    <Text style={styles.title}>LeaveDesk</Text>
    <Text style={styles.subtitle}>Your holidays, all in one place.</Text>
    <Pressable disabled={busy} style={styles.primary} onPress={signIn}><Text style={styles.primaryText}>{busy ? 'Opening secure sign-in…' : 'Sign in with your company account'}</Text></Pressable>
    <Text style={styles.footnote}>Secure company identity-provider sign-in</Text>
  </SafeAreaView>;

  const pending = requests.filter(r => r.status === 'pending').reduce((sum, r) => sum + r.working_days, 0);
  const approved = requests.filter(r => r.status === 'approved').reduce((sum, r) => sum + r.working_days, 0);
  const entitlement = profile?.annual_entitlement_days ?? 0;
  return <SafeAreaView style={styles.screen}>
    <ScrollView contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <View><Text style={styles.kicker}>EMPLOYEE WORKSPACE</Text><Text style={styles.title}>Your time off</Text><Text style={styles.subtitle}>{profile?.display_name ?? session.user.email}</Text></View>
        <Pressable onPress={signOut}><Text style={styles.link}>Sign out</Text></Pressable>
      </View>
      <View style={styles.stats}>
        <View style={styles.stat}><Text style={styles.statLabel}>Allowance</Text><Text style={styles.statNumber}>{entitlement}</Text><Text style={styles.muted}>days per leave year</Text></View>
        <View style={styles.stat}><Text style={styles.statLabel}>Approved</Text><Text style={styles.statNumber}>{approved}</Text><Text style={styles.muted}>days booked</Text></View>
        <View style={styles.stat}><Text style={styles.statLabel}>Pending</Text><Text style={styles.statNumber}>{pending}</Text><Text style={styles.muted}>days requested</Text></View>
      </View>
      <Pressable style={styles.primary} onPress={requestLeave}><Text style={styles.primaryText}>＋ Book a holiday</Text></Pressable>
      <View style={styles.card}>
        <Text style={styles.cardTitle}>My requests</Text>
        {requests.length === 0 ? <Text style={styles.muted}>You have no requests yet.</Text> : requests.map(item => <View key={item.id} style={styles.requestRow}>
          <View style={{ flex: 1 }}><Text style={styles.requestDate}>{item.start_date} – {item.end_date}</Text><Text style={styles.muted}>{item.working_days} working day(s) · {item.leave_type}</Text></View>
          <Text style={[styles.status, item.status === 'approved' ? styles.approved : item.status === 'declined' ? styles.declined : styles.pending]}>{item.status}</Text>
        </View>)}
      </View>
      <Text style={styles.footnote}>Balances and requests are provided by your organisation's LeaveDesk service.</Text>
    </ScrollView>
    <Modal visible={bookingOpen} animationType="slide" transparent onRequestClose={() => setBookingOpen(false)}>
      <View style={styles.modalShade}>
        <View style={styles.modalCard}>
          <Text style={styles.cardTitle}>Book a holiday</Text>
          <Text style={styles.muted}>Enter dates in YYYY-MM-DD format. Your organisation's policy and bank-holiday rules are checked on the server.</Text>
          <Text style={styles.inputLabel}>First day off</Text>
          <TextInput value={startDate} onChangeText={setStartDate} placeholder="2026-12-21" autoCapitalize="none" keyboardType="numbers-and-punctuation" style={styles.input} />
          <Text style={styles.inputLabel}>Last day off</Text>
          <TextInput value={endDate} onChangeText={setEndDate} placeholder="2026-12-24" autoCapitalize="none" keyboardType="numbers-and-punctuation" style={styles.input} />
          <Text style={styles.inputLabel}>Note to manager (optional)</Text>
          <TextInput value={note} onChangeText={setNote} placeholder="Add a short note" multiline style={[styles.input, { minHeight: 74, textAlignVertical: 'top' }]} />
          <Pressable disabled={busy} style={styles.primary} onPress={submitRequest}><Text style={styles.primaryText}>{busy ? 'Submitting…' : 'Submit for approval'}</Text></Pressable>
          <Pressable style={styles.cancelButton} onPress={() => setBookingOpen(false)}><Text style={styles.link}>Cancel</Text></Pressable>
        </View>
      </View>
    </Modal>
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#F5F8FA' }, content: { padding: 20, paddingBottom: 40 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#F5F8FA', padding: 28 },
  brandMark: { width: 64, height: 64, borderRadius: 20, backgroundColor: '#D9F5EB', alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  markText: { color: '#147D64', fontWeight: '900', fontSize: 22 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22 },
  kicker: { color: '#64748B', fontSize: 10, fontWeight: '800', letterSpacing: 1.5 },
  title: { color: '#172B4D', fontSize: 28, fontWeight: '800', marginTop: 6 },
  subtitle: { color: '#64748B', fontSize: 14, marginTop: 5, marginBottom: 22 },
  stats: { flexDirection: 'row', gap: 8, marginBottom: 16 },
  stat: { flex: 1, backgroundColor: 'white', borderColor: '#E2E8F0', borderWidth: 1, borderRadius: 13, padding: 12 },
  statLabel: { color: '#64748B', fontSize: 11 }, statNumber: { color: '#172B4D', fontWeight: '800', fontSize: 25, marginVertical: 8 },
  muted: { color: '#64748B', fontSize: 11, lineHeight: 17 }, primary: { backgroundColor: '#147D64', padding: 15, borderRadius: 11, alignItems: 'center', marginBottom: 18, width: '100%' },
  primaryText: { color: 'white', fontWeight: '800', fontSize: 14 }, card: { backgroundColor: 'white', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 13, padding: 16, marginBottom: 18 },
  cardTitle: { fontSize: 16, color: '#172B4D', fontWeight: '800', marginBottom: 10 }, requestRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderTopWidth: 1, borderTopColor: '#EDF1F5', gap: 10 },
  requestDate: { color: '#172B4D', fontSize: 12, fontWeight: '700', marginBottom: 4 }, status: { overflow: 'hidden', borderRadius: 12, paddingHorizontal: 9, paddingVertical: 5, fontSize: 10, fontWeight: '800', textTransform: 'capitalize' },
  approved: { backgroundColor: '#D8F5E8', color: '#176B50' }, pending: { backgroundColor: '#FFF0CC', color: '#8B5E0A' }, declined: { backgroundColor: '#FEE2E2', color: '#A12C2C' },
  modalShade: { flex: 1, backgroundColor: '#172B4D88', justifyContent: 'flex-end' }, modalCard: { backgroundColor: 'white', borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 22, paddingBottom: 32 }, inputLabel: { color: '#475569', fontWeight: '700', fontSize: 12, marginTop: 12, marginBottom: 6 }, input: { borderWidth: 1, borderColor: '#D8E1EB', borderRadius: 9, padding: 12, color: '#172B4D', fontSize: 14 }, cancelButton: { alignItems: 'center', padding: 10 }, link: { color: '#147D64', fontWeight: '700', fontSize: 12 }, footnote: { color: '#94A3B8', fontSize: 10, lineHeight: 16, textAlign: 'center', marginTop: 12 }
});
