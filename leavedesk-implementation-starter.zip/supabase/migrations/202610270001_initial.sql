-- LeaveDesk initial schema. Review and test in a non-production Supabase project first.
create extension if not exists pgcrypto;

create type public.member_role as enum ('employee', 'manager', 'hr_admin', 'org_admin');
create type public.leave_request_status as enum ('pending', 'approved', 'declined', 'cancelled');
create type public.bank_holiday_region as enum ('england_wales', 'scotland', 'northern_ireland');

create table public.organisations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  leave_year_start_month smallint not null default 1 check (leave_year_start_month between 1 and 12),
  leave_year_start_day smallint not null default 1 check (leave_year_start_day between 1 and 28),
  created_at timestamptz not null default now()
);

create table public.organisation_memberships (
  id uuid primary key default gen_random_uuid(),
  organisation_id uuid not null references public.organisations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  employee_number text,
  display_name text not null,
  work_email text not null,
  role public.member_role not null default 'employee',
  manager_membership_id uuid references public.organisation_memberships(id),
  region public.bank_holiday_region not null default 'england_wales',
  work_days smallint[] not null default array[1,2,3,4,5]::smallint[],
  start_date date not null default current_date,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (organisation_id, user_id),
  unique (organisation_id, employee_number),
  check (array_length(work_days, 1) between 1 and 7),
  check (work_days <@ array[1,2,3,4,5,6,7]::smallint[])
);

create table public.leave_policies (
  id uuid primary key default gen_random_uuid(),
  organisation_id uuid not null references public.organisations(id) on delete cascade,
  name text not null,
  annual_entitlement_days numeric(6,2) not null check (annual_entitlement_days >= 0),
  bank_holidays_included boolean not null default true,
  accrual_method text not null default 'annual' check (accrual_method in ('annual','monthly','none')),
  carry_over_days numeric(6,2) not null default 0 check (carry_over_days >= 0),
  enabled boolean not null default true,
  created_at timestamptz not null default now(),
  unique (organisation_id, name)
);

create table public.employee_policy_assignments (
  id uuid primary key default gen_random_uuid(),
  organisation_id uuid not null references public.organisations(id) on delete cascade,
  membership_id uuid not null references public.organisation_memberships(id) on delete cascade,
  policy_id uuid not null references public.leave_policies(id),
  effective_from date not null,
  effective_to date,
  created_at timestamptz not null default now(),
  check (effective_to is null or effective_to >= effective_from)
);

create table public.bank_holidays (
  id uuid primary key default gen_random_uuid(),
  region public.bank_holiday_region not null,
  holiday_date date not null,
  title text not null,
  source text not null default 'GOV.UK',
  imported_at timestamptz not null default now(),
  unique (region, holiday_date, title)
);

create table public.leave_requests (
  id uuid primary key default gen_random_uuid(),
  organisation_id uuid not null references public.organisations(id) on delete cascade,
  membership_id uuid not null references public.organisation_memberships(id),
  start_date date not null,
  end_date date not null,
  working_days numeric(6,2) not null check (working_days > 0),
  leave_type text not null default 'annual',
  employee_note text,
  status public.leave_request_status not null default 'pending',
  decided_by uuid references public.organisation_memberships(id),
  decided_at timestamptz,
  manager_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (end_date >= start_date)
);

create table public.approval_history (
  id uuid primary key default gen_random_uuid(),
  organisation_id uuid not null references public.organisations(id) on delete cascade,
  request_id uuid not null references public.leave_requests(id) on delete cascade,
  actor_membership_id uuid references public.organisation_memberships(id),
  action text not null check (action in ('submitted','approved','declined','cancelled','adjusted')),
  note text,
  created_at timestamptz not null default now()
);

create table public.leave_balance_adjustments (
  id uuid primary key default gen_random_uuid(),
  organisation_id uuid not null references public.organisations(id) on delete cascade,
  membership_id uuid not null references public.organisation_memberships(id),
  amount_days numeric(6,2) not null,
  reason text not null,
  created_by uuid not null references public.organisation_memberships(id),
  created_at timestamptz not null default now()
);

create index leave_requests_org_status_dates on public.leave_requests (organisation_id, status, start_date, end_date);
create index memberships_org_user on public.organisation_memberships (organisation_id, user_id);
create index bank_holidays_region_date on public.bank_holidays (region, holiday_date);

create or replace function public.current_membership(p_org uuid default null)
returns setof public.organisation_memberships
language sql stable security invoker
set search_path = public
as $$
  select m.* from public.organisation_memberships m
  where m.user_id = auth.uid() and m.active
    and (p_org is null or m.organisation_id = p_org);
$$;

create or replace function public.is_org_admin(p_org uuid)
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.organisation_memberships m
    where m.organisation_id = p_org and m.user_id = auth.uid()
      and m.active and m.role in ('org_admin','hr_admin')
  );
$$;

create or replace function public.is_manager_for(p_org uuid, p_member uuid)
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.organisation_memberships actor
    join public.organisation_memberships target
      on target.manager_membership_id = actor.id
     and target.organisation_id = actor.organisation_id
    where actor.user_id = auth.uid() and actor.active
      and actor.organisation_id = p_org and target.id = p_member
      and actor.role in ('manager','hr_admin','org_admin')
  );
$$;

-- Weekday numbering: PostgreSQL isodow 1=Monday ... 7=Sunday.
create or replace function public.calculate_working_days(
  p_org uuid, p_membership uuid, p_start date, p_end date
) returns numeric
language plpgsql stable security definer
set search_path = public
as $$
declare
  v_region public.bank_holiday_region;
  v_work_days smallint[];
  v_include_bank_holidays boolean;
  v_total numeric(6,2);
begin
  if p_end < p_start then raise exception 'End date must be on or after start date'; end if;
  select m.region, m.work_days, lp.bank_holidays_included
    into v_region, v_work_days, v_include_bank_holidays
  from public.organisation_memberships m
  join public.employee_policy_assignments epa on epa.membership_id = m.id
    and epa.organisation_id = m.organisation_id
    and epa.effective_from <= p_start
    and (epa.effective_to is null or epa.effective_to >= p_end)
  join public.leave_policies lp on lp.id = epa.policy_id and lp.enabled
  where m.id = p_membership and m.organisation_id = p_org and m.active
  order by epa.effective_from desc limit 1;
  if v_work_days is null then raise exception 'No active leave policy assignment covers the requested dates'; end if;

  select count(*)::numeric into v_total
  from generate_series(p_start, p_end, interval '1 day') d
  where extract(isodow from d)::smallint = any(v_work_days)
    and (
      v_include_bank_holidays
      or not exists (
        select 1 from public.bank_holidays bh
        where bh.region = v_region and bh.holiday_date = d::date
      )
    );
  return v_total;
end;
$$;

create or replace function public.my_leave_profile()
returns table (display_name text, role public.member_role, organisation_id uuid, annual_entitlement_days numeric)
language sql stable security invoker
set search_path = public
as $$
  select m.display_name, m.role, m.organisation_id, lp.annual_entitlement_days
  from public.organisation_memberships m
  join public.employee_policy_assignments epa on epa.membership_id = m.id and epa.organisation_id = m.organisation_id
    and current_date >= epa.effective_from and (epa.effective_to is null or current_date <= epa.effective_to)
  join public.leave_policies lp on lp.id = epa.policy_id and lp.enabled
  where m.user_id = auth.uid() and m.active
  order by epa.effective_from desc limit 1;
$$;

create or replace function public.my_leave_requests()
returns table (id uuid, start_date date, end_date date, working_days numeric, leave_type text, status public.leave_request_status, employee_note text)
language sql stable security invoker
set search_path = public
as $$
  select lr.id, lr.start_date, lr.end_date, lr.working_days, lr.leave_type, lr.status, lr.employee_note
  from public.leave_requests lr
  join public.organisation_memberships m on m.id = lr.membership_id
  where m.user_id = auth.uid() and m.active
  order by lr.start_date desc limit 100;
$$;

create or replace function public.submit_leave_request(
  p_start date, p_end date, p_leave_type text default 'annual', p_note text default null
) returns uuid
language plpgsql security definer
set search_path = public
as $$
declare
  v_member public.organisation_memberships%rowtype;
  v_days numeric;
  v_policy public.leave_policies%rowtype;
  v_balance numeric;
  v_request uuid;
begin
  select * into v_member from public.organisation_memberships
  where user_id = auth.uid() and active
  order by created_at limit 1;
  if v_member.id is null then raise exception 'No active employee membership found'; end if;
  if p_start < current_date then raise exception 'Leave must start today or in the future'; end if;
  if p_end < p_start then raise exception 'End date must be on or after start date'; end if;
  if p_leave_type <> 'annual' then raise exception 'This starter currently supports annual leave requests only'; end if;

  if exists (
    select 1 from public.leave_requests lr
    where lr.membership_id = v_member.id and lr.status in ('pending','approved')
      and daterange(lr.start_date, lr.end_date, '[]') && daterange(p_start, p_end, '[]')
  ) then raise exception 'Dates overlap a pending or approved request'; end if;

  v_days := public.calculate_working_days(v_member.organisation_id, v_member.id, p_start, p_end);
  if v_days <= 0 then raise exception 'Date range contains no working days'; end if;

  select lp.* into v_policy
  from public.employee_policy_assignments epa join public.leave_policies lp on lp.id = epa.policy_id
  where epa.membership_id = v_member.id and epa.organisation_id = v_member.organisation_id
    and epa.effective_from <= p_start and (epa.effective_to is null or epa.effective_to >= p_end) and lp.enabled
  order by epa.effective_from desc limit 1;
  if v_policy.id is null then raise exception 'No active leave policy covers the requested dates'; end if;

  select v_policy.annual_entitlement_days
    - coalesce((select sum(lr.working_days) from public.leave_requests lr
       where lr.membership_id = v_member.id and lr.leave_type = 'annual' and lr.status = 'approved'
         and extract(year from lr.start_date) = extract(year from p_start)),0)
    - coalesce((select sum(lr.working_days) from public.leave_requests lr
       where lr.membership_id = v_member.id and lr.leave_type = 'annual' and lr.status = 'pending'
         and extract(year from lr.start_date) = extract(year from p_start)),0)
    + coalesce((select sum(a.amount_days) from public.leave_balance_adjustments a
       where a.membership_id = v_member.id),0)
    into v_balance;
  if v_days > v_balance then raise exception 'Insufficient available leave balance'; end if;

  insert into public.leave_requests(organisation_id,membership_id,start_date,end_date,working_days,leave_type,employee_note)
  values(v_member.organisation_id,v_member.id,p_start,p_end,v_days,p_leave_type,left(p_note,1000))
  returning id into v_request;

  insert into public.approval_history(organisation_id,request_id,actor_membership_id,action,note)
  values(v_member.organisation_id,v_request,v_member.id,'submitted',left(p_note,1000));
  return v_request;
end;
$$;

create or replace function public.manager_pending_requests()
returns table (id uuid, employee_name text, start_date date, end_date date, working_days numeric, leave_type text, employee_note text, status public.leave_request_status)
language sql stable security invoker
set search_path = public
as $$
  select lr.id, m.display_name, lr.start_date, lr.end_date, lr.working_days, lr.leave_type, lr.employee_note, lr.status
  from public.leave_requests lr
  join public.organisation_memberships m on m.id = lr.membership_id
  where lr.status = 'pending'
    and (
      public.is_org_admin(lr.organisation_id)
      or exists (
        select 1 from public.organisation_memberships actor
        where actor.user_id = auth.uid() and actor.active
          and actor.id = m.manager_membership_id
          and actor.organisation_id = m.organisation_id
          and actor.role in ('manager','hr_admin','org_admin')
      )
    )
  order by lr.created_at;
$$;

create or replace function public.decide_leave_request(
  p_request_id uuid, p_decision text, p_manager_note text default null
) returns void
language plpgsql security definer
set search_path = public
as $$
declare
  v_request public.leave_requests%rowtype;
  v_actor public.organisation_memberships%rowtype;
  v_status public.leave_request_status;
begin
  if p_decision not in ('approve','decline') then raise exception 'Decision must be approve or decline'; end if;
  select * into v_request from public.leave_requests where id = p_request_id for update;
  if v_request.id is null then raise exception 'Request not found'; end if;
  if v_request.status <> 'pending' then raise exception 'Request is no longer pending'; end if;

  select * into v_actor from public.organisation_memberships
  where user_id = auth.uid() and active and organisation_id = v_request.organisation_id
    and (
      (public.is_org_admin(v_request.organisation_id) and role in ('hr_admin','org_admin'))
      or (
        id = (select m.manager_membership_id from public.organisation_memberships m where m.id = v_request.membership_id)
        and role in ('manager','hr_admin','org_admin')
      )
    )
  order by created_at limit 1;
  if v_actor.id is null then raise exception 'You are not authorised to decide this request'; end if;

  v_status := case when p_decision = 'approve' then 'approved'::public.leave_request_status else 'declined'::public.leave_request_status end;
  update public.leave_requests set status = v_status, decided_by = v_actor.id, decided_at = now(),
    manager_note = left(p_manager_note,1000), updated_at = now()
  where id = p_request_id;

  insert into public.approval_history(organisation_id,request_id,actor_membership_id,action,note)
  values(v_request.organisation_id,p_request_id,v_actor.id,p_decision || 'd',left(p_manager_note,1000));
end;
$$;

-- Enable RLS on all tenant tables.
alter table public.organisations enable row level security;
alter table public.organisation_memberships enable row level security;
alter table public.leave_policies enable row level security;
alter table public.employee_policy_assignments enable row level security;
alter table public.bank_holidays enable row level security;
alter table public.leave_requests enable row level security;
alter table public.approval_history enable row level security;
alter table public.leave_balance_adjustments enable row level security;

create policy "members can view their organisations" on public.organisations for select
using (exists(select 1 from public.organisation_memberships m where m.organisation_id=id and m.user_id=auth.uid() and m.active));

create policy "members can view organisation membership" on public.organisation_memberships for select
using (user_id=auth.uid() or public.is_org_admin(organisation_id) or public.is_manager_for(organisation_id,id));

create policy "employees can view assigned policies" on public.leave_policies for select
using (exists(select 1 from public.employee_policy_assignments a join public.organisation_memberships m on m.id=a.membership_id where a.policy_id=id and m.user_id=auth.uid() and m.active)
or public.is_org_admin(organisation_id));

create policy "members can view their policy assignments" on public.employee_policy_assignments for select
using (exists(select 1 from public.organisation_memberships m where m.id=membership_id and m.user_id=auth.uid() and m.active)
or public.is_org_admin(organisation_id) or public.is_manager_for(organisation_id,membership_id));

create policy "authenticated users can read bank holidays" on public.bank_holidays for select to authenticated using (true);

create policy "employees can view own requests, managers assigned requests, admins all" on public.leave_requests for select
using (exists(select 1 from public.organisation_memberships m where m.id=membership_id and m.user_id=auth.uid() and m.active)
or public.is_org_admin(organisation_id)
or public.is_manager_for(organisation_id,membership_id));

create policy "request owners can view approval history" on public.approval_history for select
using (exists(select 1 from public.leave_requests lr join public.organisation_memberships m on m.id=lr.membership_id where lr.id=request_id and m.user_id=auth.uid())
or public.is_org_admin(organisation_id)
or exists(select 1 from public.leave_requests lr where lr.id=request_id and public.is_manager_for(organisation_id,lr.membership_id)));

create policy "members can view own balance adjustments, admins manage" on public.leave_balance_adjustments for select
using (exists(select 1 from public.organisation_memberships m where m.id=membership_id and m.user_id=auth.uid() and m.active)
or public.is_org_admin(organisation_id));

-- Writes happen through narrowly-scoped RPCs rather than direct client table writes.
revoke insert, update, delete on public.organisations, public.organisation_memberships,
  public.leave_policies, public.employee_policy_assignments, public.bank_holidays,
  public.leave_requests, public.approval_history, public.leave_balance_adjustments from anon, authenticated;

grant select on public.organisations, public.organisation_memberships, public.leave_policies,
  public.employee_policy_assignments, public.bank_holidays, public.leave_requests,
  public.approval_history, public.leave_balance_adjustments to authenticated;

grant execute on function public.my_leave_profile() to authenticated;
grant execute on function public.my_leave_requests() to authenticated;
grant execute on function public.manager_pending_requests() to authenticated;
grant execute on function public.submit_leave_request(date,date,text,text) to authenticated;
grant execute on function public.decide_leave_request(uuid,text,text) to authenticated;
-- calculate_working_days is intentionally not granted to clients; it is called internally by the secured submit RPC.

-- SECURITY DEFINER helper functions must not be callable by anonymous clients.
revoke all on function public.is_org_admin(uuid) from public, anon;
revoke all on function public.is_manager_for(uuid,uuid) from public, anon;
grant execute on function public.is_org_admin(uuid) to authenticated;
grant execute on function public.is_manager_for(uuid,uuid) to authenticated;
