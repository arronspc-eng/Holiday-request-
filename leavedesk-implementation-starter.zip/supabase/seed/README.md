# UK bank holiday import

Official source: https://www.gov.uk/bank-holidays.json

Use a trusted scheduled server-side job (GitHub Actions with protected secrets, Supabase Edge Function + scheduler, or another controlled backend) to fetch the JSON and upsert:
- `england-and-wales` -> `england_wales`
- `scotland` -> `scotland`
- `northern-ireland` -> `northern_ireland`

For each event, use `date` as `holiday_date` and `title` as `title`. Validate source shape and dates before writing. Run regularly and log import results. Do not expose any service-role credential in the mobile app or web dashboard. The first migration intentionally does not seed potentially stale bank-holiday dates.
