# LeaveDesk — implementation starter

React Native + Expo mobile app (iOS/Android), Supabase/PostgreSQL backend, and a responsive React HR dashboard.

## Included
- Expo mobile starter with sign-in, leave balance, request creation, and request history screens.
- Responsive HR web starter with pending requests and approve/decline actions.
- Supabase SQL migration with organisation membership, contract-configurable leave policies, requests, bank holidays, approval history, and Row Level Security.
- Server-side RPC functions for submitting and deciding leave requests.
- UK bank-holiday sync instructions and identity-provider setup notes.

## Important status
This is a development starter, not a production-certified HR system. It has not been connected to your identity provider or Supabase project. It contains no live employee data. Review the SQL and legal/policy rules with your HR/payroll lead before production use.

## Prerequisites
- Node.js 20 LTS or newer
- A Supabase project
- An identity provider (for example Microsoft Entra ID, Okta, or another OIDC/SAML provider supported by your Supabase plan/configuration)
- Apple Developer account for App Store distribution
- Google Play Console account for Android distribution

## 1. Configure Supabase
1. Create a Supabase project.
2. In SQL Editor, run `supabase/migrations/202610270001_initial.sql`.
3. Configure Authentication > Providers for your identity provider. Add the provider's client ID/secret and redirect URLs in the provider and Supabase dashboards.
4. Add the app's redirect scheme `leavedesk://auth/callback` to the allowed redirect URLs, and configure native deep linking as needed.
5. Set the Supabase project URL and public anon key in each app's `.env` file.
6. Never put the Supabase service-role key in a mobile app or browser bundle.

## 2. Mobile app
```bash
cd apps/mobile
cp .env.example .env
npm install
npx expo start
```
Use Expo Go for basic UI development. Native SSO/deep-link behavior may require a development build and identity-provider-specific configuration.

## 3. HR web dashboard
```bash
cd apps/admin
cp .env.example .env
npm install
npm run dev
```
Open the URL Vite prints. HR users must be signed in and have the `hr_admin` role for the selected organisation.

## 4. Configure the first organisation
After an authenticated user signs in, an organisation admin needs to create the organisation and assign employee memberships, manager relationships, and policies. The starter intentionally does not include public self-service organisation creation. Use a trusted administrative process or a secured server-side provisioning script.

Required setup records:
- `organisations`: company name and default leave-year start.
- `organisation_memberships`: user ID, organisation ID, employee name, role, manager, region, work schedule and start date.
- `leave_policies`: entitlement and bank-holiday treatment for each contract/policy.
- `employee_policy_assignments`: employee-to-policy link.

## 5. Leave calculation model
The starter stores entitlement as a policy value and requests in working days. Its initial RPC excludes weekends and dates configured as non-working bank holidays for the employee's UK nation, subject to the assigned policy. This is a deliberately conservative baseline:
- It does not yet implement part-time weekly patterns, hourly/half-day leave, statutory accrual for joiners/leavers, carry-over caps, sickness interactions, or all statutory edge cases.
- Policy settings are contract-specific and must be completed before rollout.
- Do not assume all UK workers have identical bank-holiday treatment. HR must decide whether bank holidays are included in the allowance or treated separately, and how regional differences apply.
- Check the relevant UK statutory rules and employment contracts with a qualified adviser.

## 6. Bank holidays
The official UK Government feed is `https://www.gov.uk/bank-holidays.json`. See `supabase/seed/README.md` for an import approach. Do not fetch it directly from each employee's device. A scheduled server-side job should periodically import and validate dates, and log changes.

## 7. Security notes before production
- Configure and test RLS for every table and role.
- Use MFA for HR/admin accounts where possible.
- Configure Auth redirect allow-lists and identity-provider restrictions.
- Add audit logging, backups, monitoring, rate limiting and incident response.
- Validate all request inputs server-side.
- Review data retention, employee privacy notice, UK GDPR/DPA 2018 obligations and access/export/deletion procedures.
- Add automated tests for concurrency, date boundaries, bank holidays, access isolation and approval authorization.
