# Production checklist

## Identity and access
- [ ] Configure identity provider, OAuth/OIDC settings, redirect URLs, tenant restrictions and account lifecycle.
- [ ] Verify manager membership assignment and least-privilege access.
- [ ] Test all RLS policies using employee A, employee B, manager, HR admin and unauthenticated users.
- [ ] Ensure only trusted provisioning can create org admins or modify policies.

## UK leave rules
- [ ] Confirm leave year and entitlement per contract.
- [ ] Confirm bank-holiday inclusion/exclusion per contract and UK nation.
- [ ] Add part-time work patterns and hourly/half-day support if required.
- [ ] Define accrual, joiner/leaver proration, carry-over, unpaid leave and statutory leave behavior.
- [ ] Validate calculations against HR/payroll examples.

## Reliability
- [ ] Add transaction-level tests for overlapping requests and simultaneous submissions.
- [ ] Add tests for year boundaries, leap years, bank holidays and regional differences.
- [ ] Add error monitoring, database backups, restore tests and operational alerts.
- [ ] Add idempotent notification jobs and delivery retries.
- [ ] Add rate limits and abuse monitoring.

## Privacy and release
- [ ] Review UK GDPR/DPA 2018 responsibilities, privacy notice, retention and deletion rules.
- [ ] Confirm data-processing agreements and hosting region.
- [ ] Complete accessibility review and device testing.
- [ ] Obtain Apple and Google developer accounts and submit store builds.
- [ ] Run a pilot with test users and signed-off HR acceptance tests.
