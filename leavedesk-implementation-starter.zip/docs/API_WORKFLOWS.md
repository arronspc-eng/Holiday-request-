# API workflows

The client should use authenticated Supabase RPCs for workflows. Direct client writes to core tables are revoked in the migration.

## Employee
1. Authenticate via the configured company identity provider.
2. `my_leave_profile()` returns the employee's display name, role, organisation and assigned policy allowance.
3. `my_leave_requests()` returns the signed-in employee's request history.
4. `submit_leave_request(p_start, p_end, p_leave_type, p_note)` validates dates, policy assignment, overlap, bank holidays and available balance, then creates a pending request and a `submitted` audit entry.
5. Client refreshes profile and request list after mutation.

## Manager
1. `manager_pending_requests()` returns pending requests for employees assigned to the signed-in manager, or organisation-wide for HR/org admins.
2. `decide_leave_request(p_request_id, p_decision, p_manager_note)` locks the request, rechecks that it is pending and verifies manager relationship/role before changing status and writing approval history.
3. The app should notify the employee only after the transaction succeeds. Notification delivery should be queued server-side and retried independently.

## HR provisioning
Use a trusted administrative process or protected server-side function to:
- create organisation;
- create memberships linked to auth.users IDs;
- set manager membership IDs;
- create leave policies;
- assign employees to policies with effective dates;
- import bank holidays.

Do not allow users to self-assign HR/admin roles. Do not expose service-role credentials to browsers or phones.

## Recommended additional endpoints before production
- `my_leave_balance(p_leave_year_start)` returning entitlement, carry-over, adjustments, approved usage, pending reservations and available balance for a specified leave year.
- `cancel_leave_request(p_request_id)` with ownership checks and an audit event.
- `hr_upsert_membership(...)` and `hr_assign_policy(...)` for privileged provisioning.
- `sync_bank_holidays()` on a scheduled server-side job.
- Notification queue consumer for email and APNs/FCM push.
- Employee export, account deactivation and privacy request workflows.
